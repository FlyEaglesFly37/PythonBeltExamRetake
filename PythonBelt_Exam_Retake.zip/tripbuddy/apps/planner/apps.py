from django.apps import AppConfig


class PlannerConfig(AppConfig):
    name = 'planner'
